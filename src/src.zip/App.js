import './App.css';
import TaskList from './Composants/TaskList';
import React, { useState } from 'react';


function App() {

  const [taskList, setTaskList] = useState([
    {id : 0, name : 'Faire les courses', done : false},
    {id : 1, name : 'Sortir la viande du congel', done : true}
  ]);

  function add(tache){
    setTaskList([...taskList, tache]);
  }

  function restore(tab){
    setTaskList(tab)
  }

  return (
    <div className='app'>
      <h1>ToDo :</h1>
      <TaskList add={add} restore={restore} list={taskList}/>
    </div>
  )
}

export default App;
