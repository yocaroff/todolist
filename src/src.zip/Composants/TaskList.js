import React, { useState } from 'react';

function TaskList({ add, list, restore }) {
    const [inputValue, setInputValue] = useState();

    function valid(){
        if(inputValue){
            let maxId = -1;
            list.forEach(e => {
                if(e.id > maxId){
                    maxId = e.id
                }
            });
            add({id : maxId + 1, name : inputValue, done : false});
            setInputValue('');
        }
    }

    function update(elt){
        let local = [...list];
        let index = local.findIndex(element => element.id === elt.id);
        local[index].done = !local[index].done;
        restore(local);
    }

    return (
        <div className='tasklist-container'>
            <div className='taskForm'>
                <input type="text" name="taskInput" id="taskInput" value={inputValue} onChange={e => setInputValue(e.target.value)}/>
                <button className='addButton' onClick={valid}>Add Task</button>
            </div>
            <ul className='tasklist'>
                {list.map((item) => (
                    <li key={item.id} className={item.done ? 'done' : 'task'}>
                        <form><input type='checkbox' id={item.id} checked={item.done} onChange={() => update(item)}/></form>
                        {item.id + ' : ' + item.name}
                    </li>
                ))}
            </ul>
        </div>

    )
}

export default TaskList;